const express = require('express');
const router = express.Router();
const pool = require('../db');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'uchu_secret_key_2024';
// Middleware de autenticación
const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'No autorizado' });
  }
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.mozo = decoded;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Token inválido' });
  }
};
// Listar pedidos (con filtros)
router.get('/', authenticate, async (req, res) => {
  try {
    const { estado, fecha } = req.query;
    let query = 'SELECT p.*, m.numero as mesa_numero, mo.nombre as mozo_nombre FROM pedidos p LEFT JOIN mesas m ON p.mesa_id = m.id LEFT JOIN mozos mo ON p.mozo_id = mo.id';
    const params = [];
    
    if (estado) {
      query += ' WHERE p.estado = ?';
      params.push(estado);
    }
    
    if (fecha) {
      query += params.length ? ' AND' : ' WHERE';
      query += ' DATE(p.created_at) = ?';
      params.push(fecha);
    }
    
    query += ' ORDER BY p.created_at DESC';
    
    const [rows] = await pool.query(query, params);
    
    const pedidos = rows.map(p => ({
      ...p,
      items: JSON.parse(p.items || '[]')
    }));
    
    res.json(pedidos);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Error del servidor' });
  }
});
// Crear nuevo pedido (público - desde el menú)
router.post('/', async (req, res) => {
  try {
    const { items, total, tipo } = req.body;
    
    const [result] = await pool.query(
      'INSERT INTO pedidos (items, total, tipo, estado) VALUES (?, ?, ?, ?)',
      [JSON.stringify(items), total, tipo || 'aqui', 'nuevo']
    );
    
    // Notificar a los mozos
    const io = req.app.get('io');
    io.to('mozos').emit('nuevo_pedido', {
      id: result.insertId,
      items,
      total,
      tipo,
      created_at: new Date()
    });
    
    res.json({ success: true, id: result.insertId });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Error del servidor' });
  }
});
// Actualizar pedido (asignar mesa, cambiar estado)
router.put('/:id', authenticate, async (req, res) => {
  try {
    const { id } = req.params;
    const { mesa_id, estado } = req.body;
    
    let updates = [];
    let params = [];
    
    if (mesa_id !== undefined) {
      updates.push('mesa_id = ?');
      params.push(mesa_id);
    }
    
    if (estado) {
      updates.push('estado = ?');
      params.push(estado);
    }
    
    if (updates.length === 0) {
      return res.status(400).json({ error: 'No hay datos para actualizar' });
    }
    
    params.push(id);
    
    await pool.query(
      `UPDATE pedidos SET ${updates.join(', ')} WHERE id = ?`,
      params
    );
    
    // Si se asigna mesa, actualizar estado de la mesa
    if (mesa_id && estado === 'asignado') {
      await pool.query(
        'UPDATE mesas SET estado = ? WHERE id = ?',
        ['ocupada', mesa_id]
      );
    }
    
    // Si se completa, liberar la mesa
    if (estado === 'completado' && mesa_id) {
      await pool.query(
        'UPDATE mesas SET estado = ? WHERE id = ?',
        ['libre', mesa_id]
      );
    }
    
    // Notificar actualización
    const io = req.app.get('io');
    io.to('mozos').emit('pedido_actualizado', { id, mesa_id, estado });
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Error del servidor' });
  }
});
// Obtener un pedido específico
router.get('/:id', authenticate, async (req, res) => {
  try {
    const { id } = req.params;
    
    const [rows] = await pool.query(
      'SELECT p.*, m.numero as mesa_numero FROM pedidos p LEFT JOIN mesas m ON p.mesa_id = m.id WHERE p.id = ?',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Pedido no encontrado' });
    }
    
    const pedido = rows[0];
    pedido.items = JSON.parse(pedido.items || '[]');
    
    res.json(pedido);
  } catch (error) {
    res.status(500).json({ error: 'Error del servidor' });
  }
});
module.exports = router;