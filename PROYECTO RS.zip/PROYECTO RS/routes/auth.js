const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db');

const JWT_SECRET = process.env.JWT_SECRET || 'uchu_secret_key_2024';
// Login de mozo
router.post('/login', async (req, res) => {
  try {
    const { usuario, password } = req.body;
    
    const [rows] = await pool.query(
      'SELECT * FROM mozos WHERE usuario = ? AND activo = 1',
      [usuario]
    );
    
    if (rows.length === 0) {
      return res.status(401).json({ error: 'Usuario no encontrado' });
    }
    
    const mozo = rows[0];
    const validPassword = await bcrypt.compare(password, mozo.password_hash);
    
    if (!validPassword) {
      return res.status(401).json({ error: 'Contraseña incorrecta' });
    }
    
    const token = jwt.sign(
      { id: mozo.id, nombre: mozo.nombre, usuario: mozo.usuario },
      JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    res.json({
      success: true,
      token,
      mozo: { id: mozo.id, nombre: mozo.nombre, usuario: mozo.usuario }
    });
  } catch (error) {
    console.error('Error en login:', error);
    res.status(500).json({ error: 'Error del servidor' });
  }
});
// Registrar mozo (solo para setup inicial)
router.post('/register', async (req, res) => {
  try {
    const { nombre, usuario, password } = req.body;
    const passwordHash = await bcrypt.hash(password, 10);
    
    const [result] = await pool.query(
      'INSERT INTO mozos (nombre, usuario, password_hash) VALUES (?, ?, ?)',
      [nombre, usuario, passwordHash]
    );
    
    res.json({ success: true, id: result.insertId });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ error: 'Usuario ya existe' });
    }
    res.status(500).json({ error: 'Error del servidor' });
  }
});
// Verificar token
router.get('/verify', async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'No token' });
  }
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    res.json({ valid: true, mozo: decoded });
  } catch (error) {
    res.status(401).json({ error: 'Token inválido' });
  }
});
module.exports = router;