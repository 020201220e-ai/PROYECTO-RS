const express = require('express');
const router = express.Router();
const pool = require('../db');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'uchu_secret_key_2024';
const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No autorizado' });
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.mozo = decoded;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Token inválido' });
  }
};
// Listar todas las mesas
router.get('/', authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM mesas ORDER BY numero');
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: 'Error del servidor' });
  }
});
// Crear mesa (setup inicial)
router.post('/', authenticate, async (req, res) => {
  try {
    const { numero, nombre, capacidad } = req.body;
    
    const [result] = await pool.query(
      'INSERT INTO mesas (numero, nombre, capacidad) VALUES (?, ?, ?)',
      [numero, nombre || `Mesa ${numero}`, capacidad || 4]
    );
    
    res.json({ success: true, id: result.insertId });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ error: 'Número de mesa ya existe' });
    }
    res.status(500).json({ error: 'Error del servidor' });
  }
});
// Actualizar mesa
router.put('/:id', authenticate, async (req, res) => {
  try {
    const { id } = req.params;
    const { numero, nombre, capacidad, estado } = req.body;
    
    let updates = [];
    let params = [];
    
    if (numero !== undefined) { updates.push('numero = ?'); params.push(numero); }
    if (nombre !== undefined) { updates.push('nombre = ?'); params.push(nombre); }
    if (capacidad !== undefined) { updates.push('capacidad = ?'); params.push(capacidad); }
    if (estado !== undefined) { updates.push('estado = ?'); params.push(estado); }
    
    if (updates.length === 0) {
      return res.status(400).json({ error: 'No hay datos para actualizar' });
    }
    
    params.push(id);
    
    await pool.query(`UPDATE mesas SET ${updates.join(', ')} WHERE id = ?`, params);
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Error del servidor' });
  }
});
// Setup inicial - crear 15 mesas
router.post('/setup', authenticate, async (req, res) => {
  try {
    const resultados = [];
    
    for (let i = 1; i <= 15; i++) {
      try {
        const [result] = await pool.query(
          'INSERT IGNORE INTO mesas (numero, nombre, capacidad) VALUES (?, ?, ?)',
          [i, `Mesa ${i}`, 4]
        );
        resultados.push({ mesa: i, success: true });
      } catch (e) {
        resultados.push({ mesa: i, error: e.message });
      }
    }
    
    res.json({ success: true, resultados });
  } catch (error) {
    res.status(500).json({ error: 'Error del servidor' });
  }
});
module.exports = router;