const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
require('dotenv').config();
const pool = require('./db');
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" }
});
app.use(cors());
app.use(express.json());
app.use(express.static('public'));
const authRoutes = require('./routes/auth');
const pedidosRoutes = require('./routes/pedidos');
const mesasRoutes = require('./routes/mesas');
app.use('/api/auth', authRoutes);
app.use('/api/pedidos', pedidosRoutes);
app.use('/api/mesas', mesasRoutes);
app.get('/api/health', async (req, res) => {
  try {
    const connection = await pool.getConnection();
    await connection.ping();
    connection.release();
    res.json({ status: 'ok', message: 'Chicharrónería Uchu API', database: 'conectada' });
  } catch (error) {
    res.status(500).json({ status: 'error', message: 'Base de datos no conectada', error: error.message });
  }
});
io.on('connection', (socket) => {
  console.log('Cliente conectado:', socket.id);
  
  socket.on('join-mozos', () => {
    socket.join('mozos');
  });
  
  socket.on('disconnect', () => {
    console.log('Cliente desconectado');
  });
});
app.set('io', io);
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});