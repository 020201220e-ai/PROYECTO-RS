const API_URL = 'http://localhost:3000/api';
let cart = [];
let tipoPedido = 'aqui';
// Tu menú actual...
const menu = { /*tu menu existente*/ };
// Función modificada para confirmar tipo de pedido
function confirmOrder() {
  if (!cart.length) return;
  document.getElementById('tipo-pedido-modal').style.display = 'flex';
}
function confirmarTipo(tipo) {
  tipoPedido = tipo;
  document.getElementById('tipo-pedido-modal').style.display = 'none';
  enviarPedido();
}
async function enviarPedido() {
  const total = cart.reduce((s, i) => s + (i.p * i.q), 0);
  
  try {
    const res = await fetch(`${API_URL}/pedidos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        items: cart,
        total: total,
        tipo: tipoPedido
      })
    });
    
    const data = await res.json();
    if (data.success) {
      alert('✅ Pedido enviado correctamente!');
      cart = [];
      updateCart();
      toggleCart();
    }
  } catch (e) {
    alert('Error al enviar pedido. Intenta de nuevo.');
  }
}