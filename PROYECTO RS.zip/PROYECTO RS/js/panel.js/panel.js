const API_URL = 'http://localhost:3000/api';
let token = localStorage.getItem('token');
if (!token) window.location.href = 'login.html';
const mozo = JSON.parse(localStorage.getItem('mozo'));
document.getElementById('mozo-nombre').textContent = mozo.nombre;
async function fetchWithAuth(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: { ...options.headers, Authorization: `Bearer ${token}` }
  });
  if (res.status === 401) { logout(); return null; }
  return res.json();
}
async function loadPedidos() {
  const pedidos = await fetchWithAuth(`${API_URL}/pedidos?estado=nuevo`);
  const asignados = await fetchWithAuth(`${API_URL}/pedidos?estado=asignado`);
  
  const todos = [...(pedidos||[]), ...(asignados||[])];
  renderPedidos(todos);
}
function renderPedidos(pedidos) {
  const container = document.getElementById('pedidos-lista');
  container.innerHTML = pedidos.map(p => `
    <div class="pedido-card">
      <div class="pedido-header">
        <span class="pedido-id">Pedido #${p.id}</span>
        <span class="pedido-tipo">${p.tipo === 'aqui' ? '🍽️ Para aquí' : '🥡 Para llevar'}</span>
      </div>
      <div class="pedido-items">${p.items.map(i => `• ${i.e} ${i.n} x${i.q}`).join('<br>')}</div>
      <div class="pedido-total">S/. ${p.total}</div>
      ${p.tipo === 'aqui' ? `
        <select id="mesa-${p.id}">
          <option value="">Seleccionar mesa</option>
          ${[...Array(15)].map((_,i) => `<option value="${i+1}">Mesa ${i+1}</option>`).join('')}
        </select>
        <div class="pedido-actions">
          <button class="btn btn-asignar" onclick="asignarMesa(${p.id})">Asignar Mesa</button>
        </div>
      ` : `
        <div class="pedido-actions">
          <button class="btn btn-atender" onclick="cambiarEstado(${p.id}, 'atendido')">Marcar Listo</button>
        </div>
      `}
    </div>
  `).join('');
}
async function asignarMesa(pedidoId) {
  const mesaId = document.getElementById(`mesa-${pedidoId}`).value;
  if (!mesaId) return alert('Selecciona una mesa');
  
  await fetchWithAuth(`${API_URL}/pedidos/${pedidoId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mesa_id: mesaId, estado: 'asignado' })
  });
  loadPedidos();
  loadMesas();
}
async function cambiarEstado(pedidoId, estado) {
  await fetchWithAuth(`${API_URL}/pedidos/${pedidoId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ estado })
  });
  loadPedidos();
  loadMesas();
}
async function loadMesas() {
  const mesas = await fetchWithAuth(`${API_URL}/mesas`);
  document.getElementById('mesas-grid').innerHTML = mesas.map(m => `
    <div class="mesa ${m.estado}">
      <div class="mesa-numero">${m.numero}</div>
      <div class="mesa-estado">${m.estado === 'ocupada' ? '🔴 Ocupada' : '🟢 Libre'}</div>
    </div>
  `).join('');
}
function showTab(tab) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  event.target.classList.add('active');
  ['pedidos','mesas','historial'].forEach(t => document.getElementById(t+'-tab').style.display = 'none');
  document.getElementById(tab+'-tab').style.display = 'block';
  if (tab === 'pedidos') loadPedidos();
  if (tab === 'mesas') loadMesas();
}
function logout() {
  localStorage.clear();
  window.location.href = 'login.html';
}
loadPedidos();
loadMesas();