const API_URL = 'http://localhost:3000/api';

function login() {
  const usuario = document.getElementById('usuario').value;
  const password = document.getElementById('password').value;
  const errorDiv = document.getElementById('error');
  
  if (!usuario || !password) {
    errorDiv.textContent = 'Por favor completa todos los campos';
    return;
  }
  
  fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usuario, password })
  })
  .then(res => res.json())
  .then(data => {
    if (data.token) {
      localStorage.setItem('token', data.token);
      localStorage.setItem('mozo', JSON.stringify(data.mozo));
      window.location.href = 'panel.html';
    } else {
      errorDiv.textContent = data.error || 'Error en el login';
    }
  })
  .catch(err => {
    errorDiv.textContent = 'Error de conexión: ' + err.message;
  });
}

// Permitir Enter para enviar formulario
document.addEventListener('DOMContentLoaded', () => {
  const inputs = document.querySelectorAll('input');
  inputs.forEach(input => {
    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') login();
    });
  });
});
