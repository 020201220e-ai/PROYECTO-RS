#!/usr/bin/env powershell
# Script para inicializar la base de datos y iniciar el servidor

Write-Host "🍖 Chicharrónería Uchu - Script de Inicialización" -ForegroundColor Cyan

# Verificar si MySQL está disponible
Write-Host "`n✓ Verificando MySQL..." -ForegroundColor Yellow
try {
    $mysqlTest = mysql -u root -e "SELECT 1" 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ MySQL está disponible" -ForegroundColor Green
        
        Write-Host "`n✓ Inicializando base de datos..." -ForegroundColor Yellow
        $schemaPath = Join-Path $PSScriptRoot "schema.sql"
        mysql -u root < $schemaPath
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✓ Base de datos inicializada correctamente" -ForegroundColor Green
        } else {
            Write-Host "✗ Error al inicializar la base de datos" -ForegroundColor Red
        }
    } else {
        Write-Host "✗ MySQL no está disponible. Por favor instala XAMPP o MySQL Server" -ForegroundColor Red
        Write-Host "   Descarga XAMPP desde: https://www.apachefriends.org/" -ForegroundColor Yellow
        exit 1
    }
} catch {
    Write-Host "✗ No se pudo conectar a MySQL: $_" -ForegroundColor Red
    Write-Host "   Asegúrate de que MySQL está ejecutándose" -ForegroundColor Yellow
    exit 1
}

# Iniciar el servidor
Write-Host "`n🚀 Iniciando servidor Node.js..." -ForegroundColor Cyan
npm run dev
