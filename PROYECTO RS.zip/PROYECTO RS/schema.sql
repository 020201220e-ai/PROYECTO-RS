-- Crear base de datos
CREATE DATABASE IF NOT EXISTS chicharroneria_uchu;
USE chicharroneria_uchu;
-- Tabla de mozos
CREATE TABLE IF NOT EXISTS mozos (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  usuario VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  activo BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- Tabla de mesas
CREATE TABLE IF NOT EXISTS mesas (
  id INT PRIMARY KEY AUTO_INCREMENT,
  numero INT UNIQUE NOT NULL,
  nombre VARCHAR(50),
  estado ENUM('libre','ocupada') DEFAULT 'libre',
  capacidad INT DEFAULT 4,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- Tabla de pedidos
CREATE TABLE IF NOT EXISTS pedidos (
  id INT PRIMARY KEY AUTO_INCREMENT,
  items JSON NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  estado ENUM('nuevo','asignado','atendido','completado') DEFAULT 'nuevo',
  tipo ENUM('aqui','llevar') DEFAULT 'aqui',
  mesa_id INT NULL,
  mozo_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (mesa_id) REFERENCES mesas(id),
  FOREIGN KEY (mozo_id) REFERENCES mozos(id)
);
-- Insertar mozo demo (usuario: mozo1, password: uchu2024)
INSERT INTO mozos (nombre, usuario, password_hash) VALUES 
('Mozo Principal', 'mozo1', '$2a$10$rQZQZQZQZQZQZQZQZQZQZ.QZQZQZQZQZQZQZQZQZQZQZQZQZQZQZ');