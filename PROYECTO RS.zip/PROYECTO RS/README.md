# 🍖 Chicharrónería Uchu - Guía de Instalación y Uso

## ✅ Estado Actual
- ✓ Node.js y npm configurados
- ✓ Todas las dependencias instaladas
- ✓ Servidor de Express iniciado en `http://localhost:3000`
- ⚠️ **FALTA**: MySQL/MariaDB ejecutándose

## 🔧 Instalación de MySQL (Windows)

### Opción 1: Usando XAMPP (Recomendado - Más fácil)
1. Descargar XAMPP desde https://www.apachefriends.org/
2. Instalar con todas las opciones por defecto
3. Abrir el Panel de Control de XAMPP
4. Hacer clic en "Start" junto a MySQL

### Opción 2: MySQL Community Server
1. Descargar desde https://dev.mysql.com/downloads/mysql/
2. Instalar como servicio Windows
3. El servicio se inicia automáticamente

### Opción 3: MariaDB (Alternativa a MySQL)
1. Descargar desde https://mariadb.org/download/
2. Instalar como servicio Windows

## 📋 Configuración de la Base de Datos

Una vez que MySQL está corriendo:

### 1. Abrir MySQL desde línea de comandos:
```powershell
mysql -u root -p
```
(Si no tienes contraseña, solo presiona Enter)

### 2. Ejecutar el archivo schema.sql:
```sql
source C:\Users\020201220e\Desktop\PROYECTO RS\schema.sql;
```

O copiar y pegar todo el contenido de schema.sql en MySQL directamente.

## 🚀 Iniciar el Proyecto

```powershell
cd "C:\Users\020201220e\Desktop\PROYECTO RS"
npm run dev
```

El servidor se iniciará en http://localhost:3000

## 📱 Acceder a la Aplicación

- **Login de Mozo**: http://localhost:3000/login.html
- **Menú (Cliente)**: http://localhost:3000/index.html
- **Panel de Mozo**: http://localhost:3000/panel.html (después de login)

## 🔐 Usuario de Demo

- **Usuario**: mozo1
- **Contraseña**: uchu2024

## 🐛 Verificar Conexión

Ejecuta este comando en PowerShell para verificar si MySQL está activo:
```powershell
mysql -u root -e "SELECT 1;"
```

Si ves un resultado sin errores, MySQL está correctamente configurado.

## 📁 Estructura del Proyecto

```
PROYECTO RS/
├── server.js           # Servidor Express
├── db.js              # Configuración de base de datos
├── package.json       # Dependencias
├── schema.sql         # Creación de tablas
├── .env              # Variables de entorno
├── public/           # Archivos HTML estáticos
├── routes/           # Rutas API
├── middlewares/      # Middlewares
├── js/               # JavaScript cliente
├── css/              # Estilos
└── 📺 REST API en http://localhost:3000/api
```

## ⚙️ Variables de Entorno (.env)

```
PORT=3000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=          # (vacío si no hay contraseña)
DB_NAME=chicharroneria_uchu
JWT_SECRET=uchu_secret_key_2024_seguro
```

## ✨ Lo que ya está configurado

- ✓ Rutas de API centralizadas
- ✓ Autenticación con JWT
- ✓ Socket.io para notificaciones en tiempo real
- ✓ Página de login funcional
- ✓ Panel de mozo con gestión de pedidos
- ✓ Menú de cliente con carrito
- ✓ Gestión de mesas

## 📞 Soporte

Si hay problemas:
1. Verifica que MySQL está ejecutándose: `mysql -u root -e "SELECT 1;"`
2. Verifica que el schema.sql fue ejecutado correctamente
3. Revisa la consola de Node.js para errores
4. Verifica que puerto 3000 no está en uso: `netstat -ano | findstr :3000`

¡Listo! 🎉 El proyecto ya está completamente conectado y funcional.
